﻿/* Defines settings and actions specific to game levels */
var Levels = (function () {
    var self = this;

    var Level = function() {
        this.maxColors = 6;
        this.gridSizeMultiplier = 1;
        this.maxTurns = 50;
        this.enemies = [];
    }

    function getLevelSettings(level) {
        /// <summary>Get the settings for a particular level.</summary>
        /// <param name="level" type="Number">The level to get settings for.</param>

        var levelSettings = new Level();

        switch (level) {
            case 1:
                levelSettings.maxColors = 3;
                break;
            case 2:
                levelSettings.maxColors = 4;
                levelSettings.maxTurns = 60;
                break;
            case 3:
                levelSettings.maxColors = 5;
                levelSettings.maxTurns = 70;
                break;
            case 4:
                levelSettings.maxTurns = 80;
                break;
            case 5:
                levelSettings.maxTurns = 100;
                levelSettings.enemies.push(1);
                break;
            default:
                levelSettings = null;
        }

        return levelSettings;
    }

    return {
        getLevelSettings: getLevelSettings,
        /* Highest game level allowed */
        highestLevel: 5
    };
}());